<?php
include '../core/db_connection.php';

$username = 'admin';
$password = password_hash('adminpass', PASSWORD_DEFAULT); // Replace 'adminpass' with your desired password

$stmt = $conn->prepare("INSERT INTO admin_users (username, password) VALUES (?, ?)");
$stmt->bind_param('ss', $username, $password);

if ($stmt->execute()) {
    echo "Admin user created successfully.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
